MAVProxy
--------

This is a MAVLink ground station written in python. 

Please see http://tridge.github.io/MAVProxy/ for more information

This ground station was developed as part of the CanberraUAV OBC team
entry

License
-------

MAVProxy is released under the GNU General Public License v3 or later
